use File::Copy;

$fifo = 2;
@error_list = (0);

foreach $error (@error_list)
{
    system("m2s --evg-sim detailed --evg-fifo-length $fifo --evg-error-sig $error EigenValue --load EigenValue_Kernels.bin -x 1000 > res.txt");
    
    system("cp res.txt result/result.$fifo.$error.txt"); 
    system("rm -rf res.txt");
}
