use File::Copy;

$fifo = 2;
@error_list = (25);

foreach $error (@error_list)
{
    system("m2s --evg-sim detailed --evg-fifo-length $fifo --evg-error-sig $error BinomialOption --load BinomialOption_Kernels.bin -e -x 20> res.txt");
    system("cp res.txt result/result.$fifo.$error.txt"); 
    system("rm -rf res.txt");
}
