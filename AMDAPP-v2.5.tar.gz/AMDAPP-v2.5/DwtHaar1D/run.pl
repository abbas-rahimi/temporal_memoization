use File::Copy;
$fifo = 2;
@error_list = (46000, 47000);
foreach $error (@error_list)
{
    system("m2s --evg-sim detailed --evg-fifo-length $fifo --evg-error-sig $error DwtHaar1D --load DwtHaar1D_Kernels.bin -x 1024 -e > res.txt");
    system("cp res.txt result/result.$fifo.$error.txt"); 
    system("rm -rf res.txt");
}
