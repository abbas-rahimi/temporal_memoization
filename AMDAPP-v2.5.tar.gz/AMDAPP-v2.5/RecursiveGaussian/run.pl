use File::Copy;

@fifo_list = (2);
@error_list = (0, 200, 400, 600, 700, 800, 900, 1000);

foreach $fifo (@fifo_list)
{
    foreach $error (@error_list)
    {
        system("m2s --evg-sim detailed --evg-fifo-length $fifo --evg-error-sig $error RecursiveGaussian --load RecursiveGaussian_Kernels.bin > res.txt");
        system("cp out0.bmp result/noisy.$fifo.$error.bmp"); 
        system("cp res.txt result/result.$fifo.$error.txt"); 
        system("rm -rf out0.bmp");
        system("rm -rf res.txt");
    }
}
#$error = 0;
#system("m2s --evg-sim detailed --evg-fifo-length $fifo --evg-error-sig $error RecursiveGaussian --load RecursiveGaussian_Kernels.bin > res.txt");
#system("cp out0.bmp result/noisy.$fifo.$error.bmp");
#system("cp res.txt result/result.$fifo.$error.txt");


